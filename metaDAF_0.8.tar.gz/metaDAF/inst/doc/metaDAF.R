## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, message=FALSE, warning=FALSE, results='hide', echo=FALSE-----
rm(list = ls())
library(metaDAF)
library(tidyverse)
data("QinJ_2012_metadata")
data("QinJ_2012_table_count")

## ----example, message=FALSE, warning=FALSE, results='hide'---------------
dataTest <- build_DAF_data(count_table = QinJ_2012_table_count,
                           metadata = QinJ_2012_metadata,
                           group_var = NULL, simulation = TRUE,
                           ControlRep = 5, FC = "Norm(5,1)", numDataPoints = 20000)

## ---- message=FALSE, warning=FALSE, results='hide'-----------------------
res <- run_DAF_analysis(data = dataTest, method = "deseq2")

## ---- message=FALSE, warning=FALSE, results='hide'-----------------------
plot_data <- generate_curve_data(dt = res$curated,
                                 threshold_var = "adjusted_pvalue")

## ---- message=FALSE, warning=FALSE, results='hide'-----------------------
curve_plot(curve_data = plot_data, type = "roc",
           plot_title = "Example of DESeq2 run", auc_limit = 1)

## ---- message=FALSE, warning=FALSE, results='hide'-----------------------
curve_plot(curve_data = plot_data, type = "pr",
           plot_title = "Example of DESeq2 run", auc_limit = 1)

## ---- message=FALSE, warning=FALSE, results='hide'-----------------------
curve_plot(curve_data = plot_data, type = "roc", auc_limit = 0.1,
           plot_title = "Example of DESeq2 run") + coord_cartesian(xlim = c(0, 0.1))

